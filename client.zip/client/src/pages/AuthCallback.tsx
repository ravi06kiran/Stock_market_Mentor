import { useEffect } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '../lib/auth';
import { useToast } from '@/hooks/use-toast';

export default function AuthCallback() {
  const [, setLocation] = useLocation();
  const { loginWithToken } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    const handleCallback = async () => {
      const params = new URLSearchParams(window.location.search);
      const token = params.get('token');
      const error = params.get('error');

      if (error) {
        toast({
          title: 'Authentication failed',
          description: 'There was a problem signing you in.',
          variant: 'destructive',
        });
        setLocation('/signin');
        return;
      }

      if (token) {
        try {
          await loginWithToken(token);
          toast({
            title: 'Welcome!',
            description: 'You have been successfully signed in.',
          });
          setLocation('/dashboard');
        } catch (error) {
          toast({
            title: 'Authentication failed',
            description: 'There was a problem signing you in.',
            variant: 'destructive',
          });
          setLocation('/signin');
        }
      }
    };

    handleCallback();
  }, [setLocation, loginWithToken]);

  return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="text-center">
        <h2 className="text-2xl font-semibold mb-2">Signing you in...</h2>
        <p className="text-muted-foreground">Please wait while we complete the authentication process.</p>
      </div>
    </div>
  );
}
