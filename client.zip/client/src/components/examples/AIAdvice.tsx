import { AIAdvice } from '../AIAdvice';

export default function AIAdviceExample() {
  return <AIAdvice portfolioScore={15} isLoading={false} />;
}