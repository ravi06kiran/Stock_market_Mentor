import { MarketMood } from '../MarketMood';

export default function MarketMoodExample() {
  return <MarketMood mood="bullish" autoUpdate={true} />;
}