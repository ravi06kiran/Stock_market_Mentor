import { ThemeToggle } from '../ui/theme-toggle';

export default function ThemeToggleExample() {
  return <ThemeToggle />;
}